import mysql.connector

mydb = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="my_oop_database"
)
mycursor = mydb.cursor()

class Barang:
    def __init__(self):
        self
    
    def select_data():
        sql = "SELECT * FROM barang"
        mycursor.execute(sql)
        myresult = mycursor.fetchall()
        for x in myresult:
            print(x)
            
    def insert_data(val1,val2,val3,val4):
        sql = "INSERT INTO barang (id, nama, stok, harga) VALUES (%s, %s, %s, %s)"
        val = (val1,val2,val3,val4)
        mycursor.execute(sql, val)
        mydb.commit()
        print(mycursor.rowcount, "Data berhasil ditambahkan...")
        
    def update_data(val1,val2,val3,val4):
        sql = "UPDATE barang SET nama = %s, stok = %s, harga = %s WHERE id = %s"
        val = (val1,val2,val3,val4)
        mycursor.execute(sql, val)
        mydb.commit()
        print(mycursor.rowcount, "Data berhasil diupdate...")
        
    def delete_data(val1):
        sql = "DELETE FROM barang WHERE id = %s"
        value = (val1, )
        mycursor.execute(sql, value)
        mydb.commit()
        print(mycursor.rowcount, "Data berhasil dihapus")