import instansi
import mahasiswa

mhs1 = mahasiswa.Mahasiswa()
mhs1 = mahasiswa.Kelompok()
mhs1.set_data(2231730086,"Fandi")
mhs1.set_kel(1,"Kelompok 3")
mhs1.tampil_data()
mhs1.tampil_kel()

ins1 = instansi.Instansi()
ins1.set_data(1,"Kominfo")
ins1.tampil_data()
